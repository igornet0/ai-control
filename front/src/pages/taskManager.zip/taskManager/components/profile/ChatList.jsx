import React from 'react';

const ChatList = () => {
  return (
    <div className="bg-white rounded-2xl shadow-lg p-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4">Chats</h2>
      <div className="space-y-4">
        {/* Элементы чатов */}
      </div>
    </div>
  );
};

export default ChatList;